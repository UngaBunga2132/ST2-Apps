#===graph.py===
class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)
            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight
            if not self.directed:
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
        if not self.directed:
            if vertex2 in self.graph and vertex1 in self.graph[vertex2]:
                self.graph[vertex2].remove(vertex1)

        if self.weighted:
            self.weights.pop((vertex1, vertex2), None)
            self.weights.pop((vertex2, vertex1), None)

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            # Remove all edges connected to this vertex first
            for v in list(self.graph):
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)

            # Remove the vertex itself
            del self.graph[vertex]

            # Clean weights
            if self.weighted:
                self.weights = {k: v for k, v in self.weights.items() if vertex not in k}

    def print_graph(self):
        for v in self.graph:
            if self.weighted:
                edges = [(nbr, self.weights.get((v, nbr), 0)) for nbr in self.graph[v]]
                print(v, "->", edges)
            else:
                print(v, "->", self.graph[v])

    # Task 2
    def bfs(self, start):
        visited = []
        queue = [start]

        while queue:
            vertex = queue.pop(0)
            if vertex not in visited:
                visited.append(vertex)
                for nbr in self.graph[vertex]:
                    if nbr not in visited:
                        queue.append(nbr)
        return visited

    # Task 3
    def dfs(self, start):
        visited = []
        stack = [start]

        while stack:
            vertex = stack.pop()
            if vertex not in visited:
                visited.append(vertex)
                for nbr in reversed(self.graph[vertex]):
                    if nbr not in visited:
                        stack.append(nbr)
        return visited


    # Task 4
    def has_undirected_cycle(self):
        visited = set()

        def dfs(v, parent):
            visited.add(v)
            for nbr in self.graph[v]:
                if nbr not in visited:
                    if dfs(nbr, v):
                        return True
                elif nbr != parent:
                    return True
            return False

        for vertex in self.graph:
            if vertex not in visited:
                if dfs(vertex, None):
                    return True
        return False


